<div>
    
</div>
<?php /**PATH C:\Users\amro qadadha\Desktop\Boycott\Boycotting\resources\views/livewire/product-search.blade.php ENDPATH**/ ?>