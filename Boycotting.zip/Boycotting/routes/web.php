<?php

use App\Http\Controllers\LevenshteinController;
use App\Models\User;
use App\Models\Message;
use App\Models\Product;
use App\Models\TempProduct;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\TempProductController;
use App\Models\Alias;
use Illuminate\Pagination\LengthAwarePaginator;

use function PHPUnit\Framework\isEmpty;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/login',[UserController::class, 'login'])->name('login');
Route::post('/users/authenticate',[UserController::class, 'authenticate']);
Route::get('/import',[ProductController::class, 'importExcel']);

Route::get('/home', function () {
    return view('home', [
        'users' => User::get()
    ]);
})->middleware('auth');
//////////////////////////////To create a user outside auth limits
Route::get('/addUser',function(){
    return view('addUser');
});
///////////////////////////////////////

//CHANGE TO ->name('store')->middleware('auth') after creating a user and modifying canDelete column
//in database to 1 to allow account to delete all users
Route::post('/users/store',[UserController::class,'store'])->name('store');
Route::post('/logout',[UserController::class, 'logout'])->name('logout');

Route::get('/Not_Found', function () {
    return view('error');
})->name('error');

Route::post('/deleteUser',[UserController::class, 'destroy'])->middleware('auth');

Route::get('/products',function(){
    return view('temp_products',[
        'tempProducts' => TempProduct::get()
    ]);
});
// ->middleware('auth');
Route::get('/perm_products', function() {
    //initialize queries
    $queryResults = [];
    $searchTerm = request('search');
    $query = Product::query();
    $query2 = Product::query();
    $queryFirst = Product::query();

    if ($searchTerm) {
        $splitWords = explode(' ', $searchTerm);
        $results= [];
        //check for full name first
        $queryFirst->where(function($q) use ($searchTerm) {
                $q->orWhere('ar_name', 'like', $searchTerm. '%');
        });
        $results = $queryFirst->get();
        //handle full name
        if (!$results->isEmpty()) {
            $perPage = 10;
            $page = request()->input('page', 1); // Get the current page from the request, default to 1 if not provided
            $total = $results->count(); // Get the total number of items
            $start = ($page - 1) * $perPage; // Calculate the start index of the items for the current page
            $items = $results->slice($start, $perPage); // Get the items for the current page
            $queryResults[] = $results; // Store the entire query result in the array

            // Create a paginator manually
            $tempProducts = new LengthAwarePaginator($items, $total, $perPage, $page, [
                'path' => \Illuminate\Pagination\Paginator::resolveCurrentPath(),
                'pageName' => 'page',
            ]);
            
            // Append the search term to the pagination links
            $tempProducts->appends(['search' => $searchTerm]);
            return view('perm_products')->with('tempProducts', $tempProducts);
        }
        else{
            foreach($splitWords as $words){
                //find the alias
                $wordsSearched = Alias::where('alias_name', 'like', '%' . $words . '%')->first();
                if($wordsSearched){
                    $aliases = Alias::where('index', $wordsSearched->index)->get();
                    if($aliases->count() > 0) { //if there are aliases
                        $query->where(function($q) use ($aliases) {
                            foreach($aliases as $alias) { 
                                //check if the alias is in the beginning of the name
                                $q->orWhere('ar_name', 'like', $alias->alias_name . '%');
                            }
                        });
                        $results = $query->orderByRaw("CASE WHEN ar_name LIKE '$words%' THEN 1 ELSE 2 END")
                        ->get();

                        if(!$query->exists()){    
                            $query2->where(function($q) use ($aliases) {
                                foreach($aliases as $alias) { 
                                //else for check if the alias is in the beginning of the name
                                    $q->orWhere('ar_name', 'like', '%' . $alias->alias_name . '%');
                                }
                            });
                            $results = $query2->orderByRaw("CASE WHEN ar_name LIKE '%$words%' THEN 1 ELSE 2 END")
                            ->get();  
                        }
                    }
                    //pagination code
                    $perPage = 10;
                    $page = request()->input('page', 1); // Get the current page from the request, default to 1 if not provided
                    $total = $results->count(); // Get the total number of items
                    $start = ($page - 1) * $perPage; // Calculate the start index of the items for the current page
                    $items = $results->slice($start, $perPage); // Get the items for the current page
                    $queryResults[] = $results; // Store the entire query result in the array

                    // Create a paginator manually
                    $tempProducts = new LengthAwarePaginator($items, $total, $perPage, $page, [
                        'path' => \Illuminate\Pagination\Paginator::resolveCurrentPath(),
                        'pageName' => 'page',
                    ]);
                    
                    // Append the search term to the pagination links
                    //dont touch
                    $tempProducts->appends(['search' => $searchTerm]);

                }
                else {
                    //if no aliases, check for name instantly
                    $tempProducts = Product::where('ar_name','like', '%'. $words . '%')->get();
                    $perPage = 10;
                    $page = request()->input('page', 1); // Get the current page from the request, default to 1 if not provided
                    $total = $tempProducts->count(); // Get the total number of items
                    $start = ($page - 1) * $perPage; // Calculate the start index of the items for the current page
                    $items = $tempProducts->slice($start, $perPage); // Get the items for the current page
                    $queryResults[] = $tempProducts; // Store the entire query result in the array

                    // Create a paginator manually
                    $tempProducts = new LengthAwarePaginator($items, $total, $perPage, $page, [
                        'path' => \Illuminate\Pagination\Paginator::resolveCurrentPath(),
                        'pageName' => 'page',
                    ]);
                    
                    $tempProducts->appends(['search' => $searchTerm]);
                }
            }
            //leven
            // return ($queryResults);
            if (count($queryResults[0]) === 0) {
                $levenWords = [];
                $levenshteinController = new LevenshteinController();
                $splitWords = explode(' ', $searchTerm);
                
            foreach($splitWords as $word){
                    $word = $levenshteinController->calculateDistance($word);
                    array_push($levenWords, $word);
                    //get the similar word
            }
            //same code as above, repeating process
            foreach($levenWords as $words){
                $wordsSearched = Alias::where('alias_name', 'like', '%' . $words . '%')->first();
                if($wordsSearched){
                    $aliases = Alias::where('index', $wordsSearched->index)->get();
                    if($aliases->count() > 0) { 
                        $query->where(function($q) use ($aliases) {
                            foreach($aliases as $alias) { 
                                $q->orWhere('ar_name', 'like', $alias->alias_name . '%');
                            }
                        });
                        $results = $query->orderByRaw("CASE WHEN ar_name LIKE '%$words%' THEN 1 ELSE 2 END")
                        ->get();

                        if(!$query->exists()){    
                            $query2->where(function($q) use ($aliases) {
                                foreach($aliases as $alias) { 
                                    $q->orWhere('ar_name', 'like', '%' . $alias->alias_name . '%');
                                }
                            });
                            $results = $query2->orderByRaw("CASE WHEN ar_name LIKE '%$words%' THEN 1 ELSE 2 END")
                            ->get();  
                        }
                    }
                    $perPage = 10;
                    $page = request()->input('page', 1); // Get the current page from the request, default to 1 if not provided
                    $total = $results->count(); // Get the total number of items
                    $start = ($page - 1) * $perPage; // Calculate the start index of the items for the current page
                    $items = $results->slice($start, $perPage); // Get the items for the current page
                    $queryResults[] = $results; // Store the entire query result in the array

                    // Create a paginator manually
                    $tempProducts = new LengthAwarePaginator($items, $total, $perPage, $page, [
                        'path' => \Illuminate\Pagination\Paginator::resolveCurrentPath(),
                        'pageName' => 'page',
                    ]);
                    
                    // Append the search term to the pagination links
                    $tempProducts->appends(['search' => $searchTerm]);
                    return view('perm_products')->with('tempProducts', $tempProducts);
                }
                else {
                    $tempProducts = Product::where('ar_name','like', '%'. $words . '%')->get();
                    $perPage = 10;
                    $page = request()->input('page', 1); // Get the current page from the request, default to 1 if not provided
                    $total = $tempProducts->count(); // Get the total number of items
                    $start = ($page - 1) * $perPage; // Calculate the start index of the items for the current page
                    $items = $tempProducts->slice($start, $perPage); // Get the items for the current page
                    $queryResults[] = $tempProducts; // Store the entire query result in the array

                    // Create a paginator manually
                    $tempProducts = new LengthAwarePaginator($items, $total, $perPage, $page, [
                        'path' => \Illuminate\Pagination\Paginator::resolveCurrentPath(),
                        'pageName' => 'page',
                    ]);
                    
                    $tempProducts->appends(['search' => $searchTerm]);
                    return view('perm_products')->with('tempProducts', $tempProducts);

                }
            }

            }
        }
    }
    else{
        //no search, returns all
        $tempProducts = Product::simplePaginate(10)->appends(['search' => $searchTerm]);
        return view('perm_products')->with('tempProducts', $tempProducts);
    }
    //intersection handling 
    if (!empty($queryResults)) {
        $intersectionResults = $queryResults[0]; // Initialize with the first set of results
    
        // Find the intersection of subsequent sets of results
        for ($i = 1; $i < count($queryResults); $i++) {
            $intersectionResults = $intersectionResults->intersect($queryResults[$i]);
        }
    }
    $perPage = 10;
    $page = request()->input('page', 1); // Get the current page from the request, default to 1 if not provided
    $total = $intersectionResults ? $intersectionResults->count() : 0; // Get the total number of items
    $start = ($page - 1) * $perPage; // Calculate the start index of the items for the current page
    $items = $intersectionResults ? $intersectionResults->slice($start, $perPage) : []; // Get the items for the current page
    
    // Create a paginator manually
    $tempProducts = new LengthAwarePaginator($items, $total, $perPage, $page, [
        'path' => \Illuminate\Pagination\Paginator::resolveCurrentPath(),
        'pageName' => 'page',
    ]);
    
    $tempProducts->appends(['search' => $searchTerm]);
    
    return view('perm_products')->with('tempProducts', $tempProducts);
});

Route::get('/calculate-distance', [LevenshteinController::class, 'calculateDistance']);
Route::post('/product/store',[ProductController::class, 'store'])->middleware('auth');
Route::post('/product/update',[ProductController::class, 'update'])->middleware('auth');
Route::post('/product/delete',[ProductController::class, 'destroy'])->middleware('auth');
Route::post('/tempProduct/store',[TempProductController::class, 'store'])->middleware('auth');
Route::post('/tempProduct/update',[TempProductController::class, 'update'])->middleware('auth');
Route::post('/tempProduct/delete',[TempProductController::class, 'destroy'])->middleware('auth');

Route::get('/messages',function(){
    return view('message',[
        'messages'=> Message::orderBy('id',"desc")->get()
    ]);
})->middleware('auth');
Route::post('/messages/store',[MessageController::class, 'store'])->middleware('auth');



Route::get('/barcode',function(){
    return view('barcode');
});


Route::get('/',function(){
   return redirect('/perm_products');
});